# Socket-Programming for Computer Networking

Supports : 
#1. Broadcasting
#2. Unicasting
#3. Multicasting
#4. Blockcasting

for

#Files and Messages

Structure : 
Server > Handlers (For each client)
Client

#Instructions:
1.Run server on a terminal by Java server
2.Run client after compiling like this : Java client <name>
#Note: Port number is hardcoded.  

